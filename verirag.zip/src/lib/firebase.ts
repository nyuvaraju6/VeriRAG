import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  projectId: "lofty-arena-05jvd",
  appId: "1:511566892303:web:cd2cf9f7d338eddb65427a",
  apiKey: "AIzaSyD0scPKy9U3KmVtc1ilK13zFV654lpQ04g",
  authDomain: "lofty-arena-05jvd.firebaseapp.com",
  storageBucket: "lofty-arena-05jvd.firebasestorage.app",
  messagingSenderId: "511566892303"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const db = getFirestore(app, "ai-studio-verirag-e80cf57d-8cef-424c-b6b5-4f112c2594a9");
