/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { ArrowLeft, Check, AlertTriangle, FileText, ChevronDown, ChevronUp } from "lucide-react";
import { ModelResponse, ConsensusMetrics, Chunk } from "../types";
import { motion, AnimatePresence } from "motion/react";
import ReactMarkdown from "react-markdown";

interface PlaygroundProps {
  prompt: string;
  models: ModelResponse[];
  consensus: ConsensusMetrics;
  retrievedChunks: Chunk[];
  isLoading: boolean;
  onNavigateToLanding: () => void;
  onReverifySubmit: (prompt: string) => void;
}

export default function Playground({
  prompt,
  models,
  consensus,
  retrievedChunks,
  isLoading,
  onNavigateToLanding,
}: PlaygroundProps) {
  const [selectedModel, setSelectedModel] = useState<string | null>(null);

  // Compute aggregate counts
  const totalEvidenceCount = retrievedChunks.length;
  const totalUnsupportedCount = models.reduce((sum, m) => sum + m.unsupportedClaims.length, 0);

  // For the verified answer, we can use the consensus summary or the first model's response if it's identical
  const verifiedAnswer = consensus?.summary || "Analyzing response...";

  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 py-8 space-y-8 text-slate-900 dark:text-slate-100 min-h-screen">
      {/* Top Header */}
      <div className="flex items-center space-x-4">
        <button
          onClick={onNavigateToLanding}
          className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h2 className="text-xl font-medium tracking-tight">Verification Result</h2>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center py-20">
          <div className="animate-pulse flex flex-col items-center space-y-4">
            <div className="h-8 w-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-sm text-slate-500">Verifying with multiple models...</p>
          </div>
        </div>
      ) : (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          {/* User Prompt */}
          <div className="bg-slate-50 dark:bg-slate-900 p-6 rounded-2xl border border-slate-100 dark:border-slate-800">
            <p className="text-lg font-medium">{prompt}</p>
          </div>

          {/* Verification Summary Card */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 p-6 bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <div>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Trust Score</p>
              <p className="text-3xl font-bold text-emerald-600 dark:text-emerald-400">{consensus.overallTrustScore}%</p>
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Consensus</p>
              <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400">{consensus.agreementPercentage}%</p>
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Evidence</p>
              <p className="text-3xl font-bold text-slate-800 dark:text-slate-200">{totalEvidenceCount}</p>
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">Issues</p>
              <p className="text-3xl font-bold text-rose-600 dark:text-rose-400">{totalUnsupportedCount}</p>
            </div>
          </div>

          {/* Best Verified Answer Card */}
          <div className="relative p-6 bg-emerald-50/50 dark:bg-emerald-950/20 rounded-2xl border border-emerald-200 dark:border-emerald-800/50 shadow-sm mt-8 space-y-6">
            <h2 className="text-xl font-semibold text-emerald-800 dark:text-emerald-300 flex items-center">
              🏆 Best Verified Answer
            </h2>
            
            <div className="prose prose-slate dark:prose-invert max-w-none text-xl leading-relaxed font-medium text-slate-900 dark:text-slate-100">
              <ReactMarkdown>{verifiedAnswer}</ReactMarkdown>
            </div>
            
            <div className="pt-6 border-t border-emerald-200/50 dark:border-emerald-800/30 space-y-4">
              <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Why this answer was selected
              </h3>
              
              <ul className="list-disc list-inside space-y-1 text-sm text-slate-700 dark:text-slate-300">
                {consensus.agreementPercentage >= 80 && <li>Highest agreement among AI models.</li>}
                <li>Confidence percentage of {consensus.overallTrustScore}%.</li>
                <li>Agreement percentage of {consensus.agreementPercentage}%.</li>
                {totalEvidenceCount > 0 ? (
                  <li>Supported by {totalEvidenceCount} evidence snippet(s).</li>
                ) : (
                  <li>No evidence available to support this answer.</li>
                )}
                {consensus.mostReliableModel && <li>Best model used: {consensus.mostReliableModel}.</li>}
                {consensus.conflicts && consensus.conflicts.length > 0 && (
                  <li>Conflicts detected: {consensus.conflicts.join(", ")}</li>
                )}
              </ul>
              
              <div className="flex flex-wrap gap-4 pt-2 text-sm">
                <div className="flex items-center bg-white/50 dark:bg-slate-950/50 px-2.5 py-1 rounded-md border border-emerald-100 dark:border-emerald-900/30 text-slate-600 dark:text-slate-400">
                  <span className="font-medium mr-1 text-slate-800 dark:text-slate-200">Confidence:</span> {consensus.overallTrustScore}%
                </div>
                <div className="flex items-center bg-white/50 dark:bg-slate-950/50 px-2.5 py-1 rounded-md border border-emerald-100 dark:border-emerald-900/30 text-slate-600 dark:text-slate-400">
                  <span className="font-medium mr-1 text-slate-800 dark:text-slate-200">Agreement:</span> {consensus.agreementPercentage}%
                </div>
                <div className={`flex items-center px-2.5 py-1 rounded-md border ${
                  totalEvidenceCount > 0 
                    ? "bg-emerald-100/50 dark:bg-emerald-900/30 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300"
                    : "bg-amber-100/50 dark:bg-amber-900/30 border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300"
                }`}>
                  <span className="font-medium">
                    {totalEvidenceCount > 0 ? "Supported by Evidence" : "⚠ No Evidence"}
                  </span>
                </div>
                {consensus.mostReliableModel && (
                  <div className="flex items-center bg-white/50 dark:bg-slate-950/50 px-2.5 py-1 rounded-md border border-emerald-100 dark:border-emerald-900/30 text-slate-600 dark:text-slate-400">
                    <span className="font-medium mr-1 text-slate-800 dark:text-slate-200">Best Model:</span> {consensus.mostReliableModel}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* AI Model Responses */}
          <div className="space-y-4 pt-4">
            <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">AI Model Responses</h3>
            
            {consensus.agreementPercentage > 95 || models.every(m => m.unsupportedClaims.length === 0) ? (
              <div className="bg-slate-50 dark:bg-slate-900/50 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 text-sm text-slate-600 dark:text-slate-400 flex items-center">
                <Check className="h-4 w-4 text-emerald-500 mr-2" />
                All models agree with the Best Verified Answer.
              </div>
            ) : null}

            <div className="flex flex-wrap gap-2">
              {models.map(model => {
                const hasIssues = model.unsupportedClaims.length > 0;
                const agreesWithFinal = model.unsupportedClaims.length === 0 && model.groundedClaims.length > 0;
                return (
                  <button
                    key={model.modelName}
                    onClick={() => setSelectedModel(selectedModel === model.modelName ? null : model.modelName)}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-full border text-sm font-medium transition-colors ${
                      selectedModel === model.modelName 
                        ? "border-slate-800 bg-slate-800 text-white dark:border-slate-200 dark:bg-slate-200 dark:text-slate-900" 
                        : "border-slate-200 bg-white hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-950 dark:hover:bg-slate-900 text-slate-700 dark:text-slate-300"
                    }`}
                  >
                    <span>{model.modelName}</span>
                    {agreesWithFinal ? (
                      <Check className="h-4 w-4 text-emerald-500" />
                    ) : hasIssues ? (
                      <AlertTriangle className="h-4 w-4 text-rose-500" />
                    ) : (
                      <AlertTriangle className="h-4 w-4 text-amber-500" />
                    )}
                  </button>
                )
              })}
            </div>

            {/* Expanded Model Response */}
            <AnimatePresence>
              {selectedModel && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden"
                >
                  {(() => {
                    const modelData = models.find(m => m.modelName === selectedModel);
                    if (!modelData) return null;
                    const agreesWithFinal = modelData.unsupportedClaims.length === 0 && modelData.groundedClaims.length > 0;
                    
                    return (
                      <div className="p-5 mt-2 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
                        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                          <h4 className="font-semibold text-lg text-slate-800 dark:text-slate-200">{modelData.modelName}</h4>
                          <div className="flex flex-wrap gap-3 text-xs">
                            <span className="flex items-center bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-2 py-1 rounded-md text-slate-600 dark:text-slate-400">
                              Confidence: <strong className="ml-1 text-slate-800 dark:text-slate-200">{modelData.confidence}%</strong>
                            </span>
                            {modelData.latency && (
                              <span className="flex items-center bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-2 py-1 rounded-md text-slate-600 dark:text-slate-400">
                                Time: <strong className="ml-1 text-slate-800 dark:text-slate-200">{modelData.latency.toFixed(2)}s</strong>
                              </span>
                            )}
                            <span className={`flex items-center border px-2 py-1 rounded-md ${
                              agreesWithFinal 
                                ? "bg-emerald-50 dark:bg-emerald-500/10 border-emerald-200 dark:border-emerald-500/20 text-emerald-700 dark:text-emerald-400" 
                                : modelData.unsupportedClaims.length > 0 && modelData.groundedClaims.length > 0 
                                ? "bg-amber-50 dark:bg-amber-500/10 border-amber-200 dark:border-amber-500/20 text-amber-700 dark:text-amber-400"
                                : "bg-rose-50 dark:bg-rose-500/10 border-rose-200 dark:border-rose-500/20 text-rose-700 dark:text-rose-400"
                            }`}>
                              {agreesWithFinal ? "✓ Matches Best Answer" : (modelData.unsupportedClaims.length > 0 && modelData.groundedClaims.length > 0) ? "⚠ Partial Match" : "✗ Conflicting Answer"}
                            </span>
                          </div>
                        </div>

                        <div>
                          <h5 className="text-xs font-medium text-slate-500 mb-2 uppercase tracking-wider">Full Response</h5>
                          <div className="prose prose-sm prose-slate dark:prose-invert max-w-none bg-white dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                            <ReactMarkdown>
                              {modelData.response || ""}
                            </ReactMarkdown>
                            
                            {!agreesWithFinal && modelData.unsupportedClaims.length > 0 && (
                              <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800">
                                <h6 className="text-xs font-semibold text-rose-600 dark:text-rose-400 mb-2 uppercase tracking-wider">Conflicting Statements</h6>
                                <ul className="list-disc list-inside space-y-1 text-slate-600 dark:text-slate-400">
                                  {modelData.unsupportedClaims.map((claim, idx) => (
                                    <li key={idx} className="text-sm bg-rose-50 dark:bg-rose-500/10 px-2 py-1 rounded inline-block mb-1">{claim}</li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        </div>

                        {modelData.evidenceUsed && modelData.evidenceUsed.length > 0 && (
                          <div>
                            <h5 className="text-xs font-medium text-slate-500 mb-2 uppercase tracking-wider">Evidence Used</h5>
                            <div className="flex flex-wrap gap-2">
                              {modelData.evidenceUsed.map((evidenceId, idx) => {
                                const chunk = retrievedChunks.find(c => c.id === evidenceId);
                                return (
                                  <span key={idx} className="flex items-center bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-2.5 py-1.5 rounded-lg text-xs text-slate-600 dark:text-slate-400">
                                    <FileText className="h-3 w-3 mr-1.5 text-indigo-500" />
                                    {chunk ? (chunk.fileName || "Document") : "Document Fragment"}
                                  </span>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Evidence */}
          {retrievedChunks.length > 0 && (
            <div className="space-y-4 pt-8">
              <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Evidence Used</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">The following retrieved document snippets support the Best Verified Answer.</p>
              <div className="space-y-3">
                {retrievedChunks.map((chunk, idx) => (
                  <EvidenceCard key={idx} chunk={chunk} />
                ))}
              </div>
            </div>
          )}

        </motion.div>
      )}
    </div>
  );
}

function EvidenceCard({ chunk }: { chunk: Chunk }) {
  const [expanded, setExpanded] = useState(false);
  
  return (
    <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-white dark:bg-slate-950 transition-all hover:border-slate-300 dark:hover:border-slate-700">
      <button 
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between p-4 text-left hover:bg-slate-50 dark:hover:bg-slate-900/50 transition-colors"
      >
        <div className="flex items-center space-x-3">
          <FileText className="h-5 w-5 text-indigo-500 shrink-0" />
          <span className="font-medium text-sm text-slate-700 dark:text-slate-300 truncate">
            {chunk.fileName || "Document"} 
          </span>
        </div>
        {expanded ? <ChevronUp className="h-5 w-5 text-slate-400 shrink-0" /> : <ChevronDown className="h-5 w-5 text-slate-400 shrink-0" />}
      </button>
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
          >
            <div className="p-4 pt-0">
              <div className="bg-slate-50 dark:bg-slate-900/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed font-mono">
                  "{chunk.text}"
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
