import React, { useEffect, useState } from "react";
import { collection, query, where, orderBy, getDocs } from "firebase/firestore";
import { db } from "../lib/firebase";
import { useAuth } from "../contexts/AuthContext";
import { Clock, CheckCircle, Database } from "lucide-react";
import ReactMarkdown from "react-markdown";

interface HistoryRecord {
  id: string;
  prompt: string;
  bestVerifiedAnswer: string;
  trustScore: number;
  agreementPercentage: number;
  evidenceCount: number;
  timestamp: any;
}

export default function HistoryPage() {
  const { user } = useAuth();
  const [history, setHistory] = useState<HistoryRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchHistory() {
      if (!user) return;
      try {
        const q = query(
          collection(db, "history"),
          where("userId", "==", user.uid),
          orderBy("timestamp", "desc")
        );
        const snapshot = await getDocs(q);
        const data = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as HistoryRecord[];
        setHistory(data);
      } catch (err) {
        console.error("Failed to fetch history:", err);
      } finally {
        setLoading(false);
      }
    }
    fetchHistory();
  }, [user]);

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-8 flex items-center space-x-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-100 dark:bg-indigo-900/30">
          <Clock className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">Recent History</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">Your previous verification sessions.</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center py-20">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
        </div>
      ) : history.length === 0 ? (
        <div className="text-center py-20 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
          <p className="text-slate-500 dark:text-slate-400">No history found. Start a new verification!</p>
        </div>
      ) : (
        <div className="space-y-6">
          {history.map(record => (
            <div key={record.id} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <div className="p-6">
                <div className="mb-4">
                  <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Prompt</h3>
                  <p className="text-lg font-medium text-slate-800 dark:text-slate-200">{record.prompt}</p>
                </div>
                
                <div className="mb-6 p-4 bg-emerald-50/50 dark:bg-emerald-950/20 rounded-xl border border-emerald-100 dark:border-emerald-800/30">
                  <h3 className="text-sm font-medium text-emerald-800 dark:text-emerald-400 flex items-center mb-2">
                    <CheckCircle className="h-4 w-4 mr-1.5" /> Best Verified Answer
                  </h3>
                  <div className="prose prose-sm prose-slate dark:prose-invert max-w-none text-slate-700 dark:text-slate-300">
                    <ReactMarkdown>{record.bestVerifiedAnswer}</ReactMarkdown>
                  </div>
                </div>

                <div className="flex flex-wrap gap-4 text-sm border-t border-slate-100 dark:border-slate-800 pt-4">
                  <div className="flex items-center text-slate-600 dark:text-slate-400">
                    <span className="font-medium mr-1 text-slate-800 dark:text-slate-200">Confidence:</span> {record.trustScore}%
                  </div>
                  <div className="flex items-center text-slate-600 dark:text-slate-400">
                    <span className="font-medium mr-1 text-slate-800 dark:text-slate-200">Agreement:</span> {record.agreementPercentage}%
                  </div>
                  <div className="flex items-center text-slate-600 dark:text-slate-400">
                    <Database className="h-4 w-4 mr-1 text-indigo-500" />
                    <span className="font-medium mr-1 text-slate-800 dark:text-slate-200">Evidence:</span> {record.evidenceCount} snippet{record.evidenceCount !== 1 && 's'}
                  </div>
                  {record.timestamp && (
                    <div className="flex items-center text-slate-500 dark:text-slate-500 ml-auto">
                      {new Date(record.timestamp.seconds * 1000).toLocaleString()}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
