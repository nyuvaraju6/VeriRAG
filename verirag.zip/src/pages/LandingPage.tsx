/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { Mic, ArrowUp, Paperclip } from "lucide-react";
import { FileRecord } from "../types";
import { motion, AnimatePresence } from "motion/react";

interface LandingPageProps {
  onVerifySubmit: (prompt: string) => void;
  uploadedFiles: FileRecord[];
  onFileUpload: (file: File) => Promise<void>;
  triggerToast: (type: "success" | "error" | "info" | "warning", text: string) => void;
}

export default function LandingPage({
  onVerifySubmit,
  uploadedFiles,
  onFileUpload,
  triggerToast,
}: LandingPageProps) {
  const [promptInput, setPromptInput] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = "en-US";
      rec.onstart = () => setIsRecording(true);
      rec.onresult = (event: any) => {
        const text = event.results[0][0].transcript;
        setPromptInput(prev => prev + (prev ? " " : "") + text);
        setIsRecording(false);
      };
      rec.onerror = (err: any) => {
        console.error("Speech recognition error:", err);
        setIsRecording(false);
      };
      rec.onend = () => setIsRecording(false);
      setRecognition(rec);
    }
  }, []);

  const handleVoiceToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    if (!recognition) {
      triggerToast("warning", "Web Speech API is not supported.");
      return;
    }
    if (isRecording) {
      recognition.stop();
    } else {
      recognition.start();
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptInput.trim()) return;
    onVerifySubmit(promptInput.trim());
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      try {
        await onFileUpload(e.target.files[0]);
      } catch (error) {
        // Error handled in App
      }
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-4rem)] px-4 sm:px-6 lg:px-8">
      
      {/* Title Area */}
      <motion.div 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center max-w-3xl mb-12"
      >
        <h1 className="text-4xl sm:text-5xl font-semibold tracking-tight text-slate-900 dark:text-slate-100 mb-4">
          Verify AI Responses with Evidence
        </h1>
        <p className="text-base text-slate-500 dark:text-slate-400">
          Upload documents or ask any question to verify AI-generated information using Retrieval-Augmented Generation.
        </p>
      </motion.div>

      {/* Input Box */}
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="w-full max-w-3xl"
      >
        <form 
          onSubmit={handleFormSubmit}
          className="relative bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm focus-within:ring-2 focus-within:ring-indigo-500/50 transition-all p-2"
        >
          <textarea
            value={promptInput}
            onChange={(e) => setPromptInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                if (promptInput.trim()) onVerifySubmit(promptInput.trim());
              }
            }}
            placeholder="Ask a question or paste a claim to verify..."
            className="w-full bg-transparent resize-none outline-none text-slate-800 dark:text-slate-200 placeholder-slate-400 px-4 py-3 min-h-[120px] max-h-[300px]"
            rows={1}
          />

          <div className="flex items-center justify-between px-2 pb-2">
            <div className="flex items-center space-x-2">
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileSelect} 
                className="hidden" 
                accept=".pdf,.docx,.txt,.csv,.json,.png,.jpg,.jpeg,.webp,.md"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center justify-center p-2 rounded-xl text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title="Attach Document"
              >
                <Paperclip className="h-5 w-5" />
              </button>
              
              <button
                type="button"
                onClick={handleVoiceToggle}
                className={`flex items-center justify-center p-2 rounded-xl transition-colors ${
                  isRecording 
                    ? "text-red-500 bg-red-50 dark:bg-red-500/10" 
                    : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                }`}
                title="Voice Input"
              >
                <Mic className="h-5 w-5" />
              </button>
              
              {uploadedFiles.length > 0 && (
                <span className="text-[10px] font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 px-2 py-1 rounded-lg">
                  {uploadedFiles.length} file{uploadedFiles.length > 1 ? 's' : ''} attached
                </span>
              )}
            </div>
            
            <button
              type="submit"
              disabled={!promptInput.trim()}
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-800 dark:hover:bg-slate-200 transition-colors"
              title="Verify"
            >
              <ArrowUp className="h-5 w-5" />
            </button>
          </div>
        </form>
        <p className="text-center text-[11px] text-slate-400 mt-4">
          Models can make mistakes. Consider verifying important information.
        </p>
      </motion.div>
    </div>
  );
}
