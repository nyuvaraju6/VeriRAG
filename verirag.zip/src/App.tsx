/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import Navbar from "./components/Navbar";
import LandingPage from "./pages/LandingPage";
import Playground from "./pages/Playground";
import LoginPage from "./pages/LoginPage";
import HistoryPage from "./pages/HistoryPage";
import ToastContainer, { ToastMessage } from "./components/Toast";
import { getFiles, uploadFile, verifyPrompt, clearFiles } from "./services/api";
import { FileRecord, ModelResponse, ConsensusMetrics, Chunk } from "./types";
import { useAuth } from "./contexts/AuthContext";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { db } from "./lib/firebase";

export default function App() {
  const { user, loading: authLoading } = useAuth();
  const [currentPath, setCurrentPath] = useState<"/" | "/playground" | "/history">("/");
  const [uploadedFiles, setUploadedFiles] = useState<FileRecord[]>([]);
  const [prompt, setPrompt] = useState("");
  
  // Toast notifications state
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  
  // States to flush upon a new prompt
  const [models, setModels] = useState<ModelResponse[]>([]);
  const [consensus, setConsensus] = useState<ConsensusMetrics | null>(null);
  const [retrievedChunks, setRetrievedChunks] = useState<Chunk[]>([]);
  
  const [isLoading, setIsLoading] = useState(false);
  const [sessionId] = useState<string>(() => "sess-" + Math.random().toString(36).substring(2, 7));

  // Theme state synced with local storage and root element class list
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    const saved = localStorage.getItem("theme");
    if (saved) return saved as "light" | "dark";
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  });

  useEffect(() => {
    console.log("Theme changed to:", theme);
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
    localStorage.setItem("theme", theme);
  }, [theme]);

  const toggleTheme = () => {
    console.log("Toggle theme called");
    setTheme((prev) => (prev === "dark" ? "light" : "dark"));
  };

  // Ref to cancel previous outstanding verify queries
  const abortControllerRef = useRef<AbortController | null>(null);

  const triggerToast = (type: "success" | "error" | "info" | "warning", text: string) => {
    const id = "toast-" + Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, type, text }]);
  };

  const handleRemoveToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync uploaded files index on mount
  useEffect(() => {
    async function loadFiles() {
      if (!user) return;
      try {
        const files = await getFiles();
        setUploadedFiles(files);
      } catch (err) {
        console.error("Failed to sync uploaded files list on mount:", err);
      }
    }
    loadFiles();
  }, [user]);

  /**
   * Handle document file upload to backend
   */
  const handleFileUpload = async (file: File) => {
    if (!user) return;
    setIsLoading(true);
    try {
      const res = await uploadFile(file);
      if (res.success) {
        triggerToast("success", `Document "${file.name}" vectorized & loaded into memory successfully!`);
        
        // Save to Firestore
        await addDoc(collection(db, "documents"), {
          userId: user.uid,
          fileName: file.name,
          type: file.type,
          size: file.size,
          timestamp: serverTimestamp()
        });
        
        // Refetch active files list to update registry stats
        const updatedFiles = await getFiles();
        setUploadedFiles(updatedFiles);
      }
    } catch (err: any) {
      setIsLoading(false);
      triggerToast("error", err.message || "Failed to upload and index document.");
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Handle verify claim prompt submit
   */
  const handleVerifySubmit = async (submittedPrompt: string) => {
    if (!user) return;
    
    // 1. Immediately cancel any previous ongoing queries as requested
    if (abortControllerRef.current) {
      console.log("Canceling outstanding model evaluation request...");
      abortControllerRef.current.abort();
      triggerToast("info", "Outstanding query aborted to start new evaluation.");
    }

    // 2. Immediately clear previous states
    setPrompt(submittedPrompt);
    setModels([]);
    setConsensus(null);
    setRetrievedChunks([]);
    setIsLoading(true);
    
    // Smoothly transition to playground so user sees active loader
    setCurrentPath("/playground");

    // 3. Setup fresh abort controller
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const res = await verifyPrompt(submittedPrompt, sessionId, controller.signal);
      
      if (res.success) {
        setModels(res.models || []);
        setConsensus(res.consensus || null);
        setRetrievedChunks(res.retrievedChunks || []);
        triggerToast("success", "Consensus calibration complete! 6 nodes synchronized.");
        
        // Save history to Firestore
        if (res.consensus) {
          await addDoc(collection(db, "history"), {
            userId: user.uid,
            prompt: submittedPrompt,
            bestVerifiedAnswer: res.consensus.summary || "",
            trustScore: res.consensus.overallTrustScore || 0,
            agreementPercentage: res.consensus.agreementPercentage || 0,
            evidenceCount: (res.retrievedChunks || []).length,
            timestamp: serverTimestamp()
          });
        }
      }
    } catch (err: any) {
      if (err.name === "AbortError") {
        console.log("Request aborted successfully.");
        return; // Don't reset loaders if it was just an abort cancellation
      }
      console.error("Error evaluating prompt:", err);
      triggerToast("error", `Model verification failed: ${err.message || "Unknown error occurred"}`);
      setCurrentPath("/"); // bounce back to landing if exception is unrecoverable
    } finally {
      setIsLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col font-sans transition-colors duration-300">
        <Navbar
          onNavigateToLanding={() => {}}
          onNavigateToHistory={() => {}}
          theme={theme}
          onToggleTheme={toggleTheme}
        />
        <main className="flex-1 overflow-x-hidden">
          <LoginPage />
        </main>
        <ToastContainer toasts={toasts} onRemove={handleRemoveToast} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col font-sans transition-colors duration-300">
      <Navbar
        onNavigateToLanding={() => setCurrentPath("/")}
        onNavigateToHistory={() => setCurrentPath("/history")}
        theme={theme}
        onToggleTheme={toggleTheme}
      />

      <main className="flex-1 overflow-x-hidden">
        {currentPath === "/" ? (
          <LandingPage
            onVerifySubmit={handleVerifySubmit}
            uploadedFiles={uploadedFiles}
            onFileUpload={handleFileUpload}
            triggerToast={triggerToast}
          />
        ) : currentPath === "/history" ? (
          <HistoryPage />
        ) : (
          <Playground
            prompt={prompt}
            models={models}
            consensus={consensus || {
              agreementPercentage: 0,
              conflicts: [],
              uniqueClaims: [],
              commonClaims: [],
              summary: "No evaluation parsed.",
              overallTrustScore: 0
            }}
            retrievedChunks={retrievedChunks}
            isLoading={isLoading}
            onNavigateToLanding={() => setCurrentPath("/")}
            onReverifySubmit={handleVerifySubmit}
          />
        )}
      </main>

      {/* Toast Overlay */}
      <ToastContainer toasts={toasts} onRemove={handleRemoveToast} />
    </div>
  );
}
