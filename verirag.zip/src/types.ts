/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Chunk {
  id: string;
  text: string;
  fileName: string;
  score?: number;
}

export interface FileRecord {
  name: string;
  size: number;
  chunkCount: number;
}

export interface ModelResponse {
  modelName: string;
  response: string;
  confidence: number; // 0-100
  hallucinationRisk: number; // 0-100
  latency: number; // in seconds
  evidenceUsed: string[]; // Chunk IDs
  groundedClaims: string[];
  unsupportedClaims: string[];
  
  // Metadata fields
  streamingStatus: "idle" | "queued" | "streaming" | "completed" | "failed";
  requestId: string;
  promptId: string;
  conversationId: string;
  sessionId: string;
}

export interface ConsensusMetrics {
  agreementPercentage: number;
  conflicts: string[];
  uniqueClaims: string[];
  commonClaims: string[];
  summary: string;
  overallTrustScore: number;
  mostReliableModel?: string;
  confidenceRanking?: string[];
  hallucinationRisk?: number;
  riskLevel?: "Low" | "Medium" | "High" | "Critical";
  trustBadge?: {
    label: string;
    colorHex: string;
    badgeClass: string;
    iconName: "ShieldCheck" | "ShieldAlert" | "AlertOctagon" | "ShieldAlertCircle";
  };
}

export interface VerificationResponse {
  success: boolean;
  prompt: string;
  retrievedChunks: Chunk[];
  models: ModelResponse[];
  consensus: ConsensusMetrics;
}

export type TrustLevel = "Excellent" | "Good" | "Average" | "Poor";

export function getTrustLevel(score: number): TrustLevel {
  if (score >= 85) return "Excellent";
  if (score >= 70) return "Good";
  if (score >= 50) return "Average";
  return "Poor";
}

export function getTrustColor(score: number): string {
  if (score >= 85) return "#10B981"; // Emerald
  if (score >= 70) return "#3B82F6"; // Blue
  if (score >= 50) return "#F59E0B"; // Amber
  return "#EF4444"; // Red
}

export function getTrustBgColor(score: number): string {
  if (score >= 85) return "bg-emerald-500/10 text-emerald-400 border-emerald-500/20";
  if (score >= 70) return "bg-blue-500/10 text-blue-400 border-blue-500/20";
  if (score >= 50) return "bg-amber-500/10 text-amber-400 border-amber-500/20";
  return "bg-red-500/10 text-red-400 border-red-500/20";
}
