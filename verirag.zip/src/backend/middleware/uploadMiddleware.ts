/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import multer from "multer";

// Configure multer to store files in memory
const storage = multer.memoryStorage();

export const upload = multer({
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    // We support PDF, DOCX, TXT, CSV, JSON and images
    const allowedMimeTypes = [
      "application/pdf",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "text/plain",
      "text/csv",
      "application/json",
      "image/png",
      "image/jpeg",
      "image/jpg",
      "image/webp"
    ];

    const fileExtension = file.originalname.split('.').pop()?.toLowerCase();
    const allowedExtensions = ["pdf", "docx", "txt", "csv", "json", "png", "jpg", "jpeg", "webp", "md"];

    if (allowedMimeTypes.includes(file.mimetype) || (fileExtension && allowedExtensions.includes(fileExtension))) {
      cb(null, true);
    } else {
      cb(new Error(`Unsupported file type: ${file.mimetype}. We support PDF, DOCX, TXT, CSV, JSON, and Images.`));
    }
  }
});
