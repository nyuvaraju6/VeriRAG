/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Trust Scoring Engine Input Parameters
 */
export interface TrustEngineInputs {
  agreementPercentage: number; // 0-100: consensus level between models
  groundedClaimsCount: number; // number of claims backed by retrieved chunks
  unsupportedClaimsCount: number; // number of claims not found in retrieved chunks
  totalRetrievedChunks: number; // number of chunks retrieved by RAG engine
  uniqueChunksCited: number; // number of chunks actively used as evidence by any model
  conflictsCount: number; // number of logical conflicts or discrepancies discovered
  completenessRating: number; // 0-100: how thoroughly the combined answers address the user's prompt
  averageLatency: number; // in seconds, average response time of the models
}

/**
 * Risk levels based on trust score and hallucination risk
 */
export type RiskLevel = "Low" | "Medium" | "High" | "Critical";

/**
 * Visual metadata for badges representing trust results
 */
export interface TrustBadgeConfig {
  label: string;
  colorHex: string;
  badgeClass: string;
  iconName: "ShieldCheck" | "ShieldAlert" | "AlertOctagon" | "ShieldAlertCircle";
}

/**
 * Trust Scoring Engine Evaluation Output
 */
export interface TrustEngineOutput {
  overallTrustScore: number; // 0-100 weighted index
  hallucinationRisk: number; // 0-100 risk rating
  riskLevel: RiskLevel;
  trustBadge: TrustBadgeConfig;
  breakdown: {
    agreementScore: number;
    groundingScore: number;
    evidenceCoverageScore: number;
    consistencyScore: number;
    completenessScore: number;
    latencyScore: number;
  };
}

/**
 * Mathematically evaluates the VeriRAG Trust Index and Hallucination Risk based on multiple metrics.
 * 
 * Weights are calibrated for production RAG verification:
 * - Grounding: 35%
 * - Agreement: 25%
 * - Consistency: 15%
 * - Completeness: 15%
 * - Evidence Coverage: 5%
 * - Latency Performance: 5%
 */
export function calculateTrustScore(inputs: TrustEngineInputs): TrustEngineOutput {
  const {
    agreementPercentage,
    groundedClaimsCount,
    unsupportedClaimsCount,
    totalRetrievedChunks,
    uniqueChunksCited,
    conflictsCount,
    completenessRating,
    averageLatency,
  } = inputs;

  // 1. Grounding Score Calculation
  let groundingScore = 100;
  const totalClaims = groundedClaimsCount + unsupportedClaimsCount;
  if (totalClaims > 0) {
    groundingScore = Math.round((groundedClaimsCount / totalClaims) * 100);
  } else if (totalRetrievedChunks > 0) {
    // Chunks exist but no claims were parsed (e.g. models returned blank or short content)
    groundingScore = 50;
  } else {
    // Unassisted generation (no context loaded at all)
    groundingScore = 20;
  }

  // 2. Agreement Score (passed directly but bounded)
  const agreementScore = Math.max(0, Math.min(100, Math.round(agreementPercentage)));

  // 3. Evidence Coverage Score
  let evidenceCoverageScore = 100;
  if (totalRetrievedChunks > 0) {
    evidenceCoverageScore = Math.round((uniqueChunksCited / totalRetrievedChunks) * 100);
  } else {
    // If no context was retrieved, coverage is inherently zero (or low confidence default)
    evidenceCoverageScore = 15;
  }

  // 4. Consistency Score (deduct points for conflicts found)
  // Each conflict deducts 15 points
  const consistencyScore = Math.max(0, 100 - conflictsCount * 15);

  // 5. Completeness Score (directly uses the rating, bounded)
  const completenessScore = Math.max(0, Math.min(100, Math.round(completenessRating)));

  // 6. Latency Score (Efficiency factor)
  // Optimal: under 1.5 seconds. Max acceptable: 8 seconds.
  let latencyScore = 100;
  if (averageLatency > 1.5) {
    const excess = averageLatency - 1.5;
    latencyScore = Math.max(0, Math.round(100 - (excess / 6.5) * 100));
  }

  // Calculate Weighted Overall Trust Score
  // Weights: Grounding (0.35), Agreement (0.25), Consistency (0.15), Completeness (0.15), Evidence (0.05), Latency (0.05)
  const weightedScore = (
    (groundingScore * 0.35) +
    (agreementScore * 0.25) +
    (consistencyScore * 0.15) +
    (completenessScore * 0.15) +
    (evidenceCoverageScore * 0.05) +
    (latencyScore * 0.05)
  );

  const overallTrustScore = Math.max(0, Math.min(100, Math.round(weightedScore)));

  // Calculate Hallucination Risk
  // Hallucination risk is strongly related to unsupported claims, low consistency, and low agreement.
  let unsupportedWeight = 0;
  if (totalClaims > 0) {
    unsupportedWeight = (unsupportedClaimsCount / totalClaims) * 100;
  } else {
    unsupportedWeight = totalRetrievedChunks > 0 ? 10 : 80;
  }

  // Weighted risk combination:
  // - Unsupported ratio: 60%
  // - Consistency gaps (100 - consistency): 20%
  // - Lack of agreement (100 - agreement): 20%
  const computedRisk = (
    (unsupportedWeight * 0.60) +
    ((100 - consistencyScore) * 0.20) +
    ((100 - agreementScore) * 0.20)
  );

  const hallucinationRisk = Math.max(0, Math.min(100, Math.round(computedRisk)));

  // Determine Risk Level based on overall trust score and hallucination risk
  let riskLevel: RiskLevel = "Critical";
  if (overallTrustScore >= 85 && hallucinationRisk <= 20) {
    riskLevel = "Low";
  } else if (overallTrustScore >= 70 && hallucinationRisk <= 40) {
    riskLevel = "Medium";
  } else if (overallTrustScore >= 45 && hallucinationRisk <= 65) {
    riskLevel = "High";
  } else {
    riskLevel = "Critical";
  }

  // Generate visual badge configurations
  let trustBadge: TrustBadgeConfig;
  switch (riskLevel) {
    case "Low":
      trustBadge = {
        label: "Verified Trusted",
        colorHex: "#10B981", // Emerald
        badgeClass: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
        iconName: "ShieldCheck",
      };
      break;
    case "Medium":
      trustBadge = {
        label: "Mild Divergence",
        colorHex: "#3B82F6", // Blue
        badgeClass: "bg-blue-500/10 text-blue-400 border-blue-500/20",
        iconName: "ShieldAlertCircle",
      };
      break;
    case "High":
      trustBadge = {
        label: "Substantial Risk",
        colorHex: "#F59E0B", // Amber
        badgeClass: "bg-amber-500/10 text-amber-400 border-amber-500/20",
        iconName: "ShieldAlert",
      };
      break;
    case "Critical":
    default:
      trustBadge = {
        label: "Highly Suspicious",
        colorHex: "#EF4444", // Red
        badgeClass: "bg-red-500/10 text-red-400 border-red-500/20",
        iconName: "AlertOctagon",
      };
      break;
  }

  return {
    overallTrustScore,
    hallucinationRisk,
    riskLevel,
    trustBadge,
    breakdown: {
      agreementScore,
      groundingScore,
      evidenceCoverageScore,
      consistencyScore,
      completenessScore,
      latencyScore,
    },
  };
}
