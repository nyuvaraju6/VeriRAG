/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Chunk {
  id: string;
  text: string;
  fileName: string;
  score?: number;
}

// In-memory document storage
let chunksStore: Chunk[] = [];
let uploadedFilesStore: { name: string; size: number; chunkCount: number }[] = [];

/**
 * Split text into chunks of specified size and overlap
 */
export function chunkText(text: string, fileName: string, chunkSize = 500, overlap = 100): Chunk[] {
  const chunks: Chunk[] = [];
  let startIndex = 0;
  let chunkIdx = 0;

  // Clean double-spaces and newlines to make chunking cleaner
  const normalizedText = text.replace(/\s+/g, ' ').trim();

  if (normalizedText.length <= chunkSize) {
    chunks.push({
      id: `${fileName}-chunk-${chunkIdx}`,
      text: normalizedText,
      fileName,
    });
    return chunks;
  }

  while (startIndex < normalizedText.length) {
    let endIndex = startIndex + chunkSize;
    
    // Adjust endIndex to not cut a word in half if possible
    if (endIndex < normalizedText.length) {
      const nextSpace = normalizedText.indexOf(' ', endIndex);
      if (nextSpace !== -1 && nextSpace - endIndex < 25) {
        endIndex = nextSpace;
      }
    } else {
      endIndex = normalizedText.length;
    }

    const chunkContent = normalizedText.substring(startIndex, endIndex).trim();
    if (chunkContent.length > 10) {
      chunks.push({
        id: `${fileName}-chunk-${chunkIdx++}`,
        text: chunkContent,
        fileName,
      });
    }

    startIndex = endIndex - overlap;
    // Prevent infinite loop if overlap is too large or progress is zero
    if (startIndex >= endIndex) {
      startIndex = endIndex;
    }
  }

  return chunks;
}

/**
 * Add document text to in-memory store
 */
export function addDocument(fileName: string, text: string, fileSize: number): { name: string; size: number; chunkCount: number } {
  const newChunks = chunkText(text, fileName);
  chunksStore.push(...newChunks);
  
  const fileRecord = {
    name: fileName,
    size: fileSize,
    chunkCount: newChunks.length
  };
  
  // Prevent duplicate files listed in file records
  uploadedFilesStore = uploadedFilesStore.filter(f => f.name !== fileName);
  uploadedFilesStore.push(fileRecord);
  
  return fileRecord;
}

/**
 * Get all files currently in memory
 */
export function getUploadedFiles() {
  return uploadedFilesStore;
}

/**
 * Clear in-memory stores
 */
export function clearStore() {
  chunksStore = [];
  uploadedFilesStore = [];
}

/**
 * Standardize and tokenize a string, removing common punctuation
 */
function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(token => token.length > 2); // filter out very short words/stop words
}

/**
 * Calculate keyword overlap/similarity score between query and a chunk
 */
export function retrieveRelevantChunks(query: string, limit = 5): Chunk[] {
  if (chunksStore.length === 0) return [];

  const queryTokens = tokenize(query);
  if (queryTokens.length === 0) {
    // If query is empty or too short, return first few chunks
    return chunksStore.slice(0, limit);
  }

  const scoredChunks = chunksStore.map(chunk => {
    const chunkTokens = tokenize(chunk.text);
    const chunkTokenSet = new Set(chunkTokens);
    
    // Count matches and compute tf-idf-like weight (rarer words get more weight)
    let matches = 0;
    queryTokens.forEach(token => {
      if (chunkTokenSet.has(token)) {
        // Boost for repeated occurrences of query term in chunk
        const countInChunk = chunkTokens.filter(t => t === token).length;
        matches += 1 + (countInChunk * 0.2);
      }
    });

    // Length normalization factor: prevent very long chunks from getting higher scores artificially
    const lengthFactor = Math.log(1 + chunkTokens.length);
    const score = matches / (lengthFactor || 1);

    return {
      ...chunk,
      score: parseFloat(score.toFixed(3)),
    };
  });

  // Filter out zero scores and sort
  return scoredChunks
    .filter(chunk => (chunk.score || 0) > 0)
    .sort((a, b) => (b.score || 0) - (a.score || 0))
    .slice(0, limit);
}

/**
 * Prepare standard structured context for feeding into an LLM prompt
 */
export function prepareContextForLLM(chunks: Chunk[]): string {
  if (!chunks || chunks.length === 0) {
    return "No document context uploaded or retrieved.";
  }
  return chunks
    .map((c, idx) => `[Chunk ${idx}] ID: ${c.id}\nSource: ${c.fileName}\nContent: ${c.text}`)
    .join("\n\n");
}

