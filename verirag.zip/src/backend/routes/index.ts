/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Router } from "express";
import { upload } from "../middleware/uploadMiddleware.js";
import { handleUpload, handleGetUploadedFiles, handleClearFiles } from "../controllers/uploadController.js";
import { handleVerify } from "../controllers/verifyController.js";

const router = Router();

// Health endpoint
const getHealth = (req: any, res: any) => {
  res.status(200).json({ status: "healthy", service: "VeriRAG Engine", timestamp: new Date().toISOString() });
};

// Route Registrations (both direct and prefixed)
router.post("/upload", upload.single("file"), handleUpload);
router.post("/api/upload", upload.single("file"), handleUpload);

router.post("/verify", handleVerify);
router.post("/api/verify", handleVerify);

router.get("/health", getHealth);
router.get("/api/health", getHealth);

// Extra helper routes for document state management
router.get("/files", handleGetUploadedFiles);
router.get("/api/files", handleGetUploadedFiles);

router.delete("/files", handleClearFiles);
router.delete("/api/files", handleClearFiles);

export default router;
