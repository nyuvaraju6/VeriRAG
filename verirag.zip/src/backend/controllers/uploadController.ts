/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Request, Response } from "express";
import { parseDocument } from "../parsers/documentParser.js";
import { addDocument, getUploadedFiles, clearStore } from "../services/ragService.js";

/**
 * Handle document upload and parsing
 */
export async function handleUpload(req: Request, res: Response): Promise<void> {
  try {
    if (!req.file) {
      res.status(400).json({ error: "No file was uploaded." });
      return;
    }

    const { originalname, mimetype, buffer, size } = req.file;
    console.log(`Processing upload: ${originalname} (${mimetype}, ${size} bytes)`);

    // Parse the document based on its type
    const parsedText = await parseDocument(buffer, mimetype, originalname);

    if (!parsedText.trim()) {
      res.status(422).json({ error: "The document could be read but no text content could be extracted." });
      return;
    }

    // Add parsed text chunks to the in-memory store
    const fileRecord = addDocument(originalname, parsedText, size);

    res.status(200).json({
      success: true,
      message: `Successfully processed and chunked "${originalname}"`,
      file: fileRecord,
    });
  } catch (err: any) {
    console.error("Error processing upload in controller:", err);
    res.status(500).json({ error: err.message || "An error occurred while parsing the file." });
  }
}

/**
 * List files in memory
 */
export function handleGetUploadedFiles(req: Request, res: Response): void {
  try {
    const files = getUploadedFiles();
    res.status(200).json({ success: true, files });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
}

/**
 * Clear the in-memory database
 */
export function handleClearFiles(req: Request, res: Response): void {
  try {
    clearStore();
    res.status(200).json({ success: true, message: "In-memory database successfully cleared." });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
}
