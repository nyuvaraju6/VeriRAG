/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Request, Response } from "express";
import { retrieveRelevantChunks } from "../services/ragService.js";
import { verifyPromptWithRAG } from "../services/llmService.js";

/**
 * Handle verification of the user prompt using RAG and consensus metrics
 */
export async function handleVerify(req: Request, res: Response): Promise<void> {
  try {
    const { prompt, sessionId } = req.body;

    if (!prompt || typeof prompt !== "string" || !prompt.trim()) {
      res.status(400).json({ error: "Please provide a valid prompt string." });
      return;
    }

    console.log(`Starting VeriRAG analysis for prompt: "${prompt.substring(0, 60)}..."`);

    // 1. Retrieve the top relevant chunks using our in-memory keyword similarity retriever
    const retrievedChunks = retrieveRelevantChunks(prompt, 5);
    console.log(`Retrieved ${retrievedChunks.length} relevant chunks for verification.`);

    // 2. Perform the LLM-driven generation and consensus metrics check
    const result = await verifyPromptWithRAG(prompt, retrievedChunks, sessionId);

    // 3. Return response containing model cards, consensus analysis, and retrieved chunks for evidence viewer
    res.status(200).json({
      success: true,
      prompt,
      retrievedChunks,
      models: result.models,
      consensus: result.consensus
    });

  } catch (err: any) {
    console.error("Error verifying prompt:", err);
    res.status(500).json({ 
      error: err.message || "An unexpected error occurred during verification." 
    });
  }
}
