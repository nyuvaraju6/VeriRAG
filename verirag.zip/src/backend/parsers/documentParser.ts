/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as pdfModule from 'pdf-parse';
// Resolve default export vs module export depending on commonjs wrapping
const pdf = (pdfModule as any).default || pdfModule;
import mammoth from 'mammoth';
import { getGeminiClient } from '../services/geminiService.js';

/**
 * Universal document parsing function that processes different mime types
 */
export async function parseDocument(
  buffer: Buffer,
  mimeType: string,
  fileName: string
): Promise<string> {
  const normalizedMime = mimeType.toLowerCase();

  // 1. PDF Documents
  if (normalizedMime === 'application/pdf' || fileName.endsWith('.pdf')) {
    try {
      const data = await pdf(buffer);
      return data.text || '';
    } catch (err: any) {
      console.error('Error parsing PDF:', err);
      throw new Error(`Failed to parse PDF document: ${err.message}`);
    }
  }

  // 2. Word Documents (DOCX)
  if (
    normalizedMime === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
    fileName.endsWith('.docx')
  ) {
    try {
      const result = await mammoth.extractRawText({ buffer });
      return result.value || '';
    } catch (err: any) {
      console.error('Error parsing DOCX:', err);
      throw new Error(`Failed to parse DOCX document: ${err.message}`);
    }
  }

  // 3. Text & Code Formats (TXT, CSV, JSON)
  if (
    normalizedMime.startsWith('text/') ||
    normalizedMime === 'application/json' ||
    fileName.endsWith('.txt') ||
    fileName.endsWith('.csv') ||
    fileName.endsWith('.json') ||
    fileName.endsWith('.md')
  ) {
    try {
      const rawText = buffer.toString('utf-8');
      
      // If it's JSON, let's parse and pretty print it to make it readable context
      if (fileName.endsWith('.json') || normalizedMime === 'application/json') {
        try {
          const parsed = JSON.parse(rawText);
          return JSON.stringify(parsed, null, 2);
        } catch {
          return rawText; // Fallback to raw text if invalid JSON
        }
      }
      return rawText;
    } catch (err: any) {
      console.error('Error parsing text file:', err);
      throw new Error(`Failed to parse text file: ${err.message}`);
    }
  }

  // 4. Image Files (OCR via Gemini API)
  if (
    normalizedMime.startsWith('image/') ||
    fileName.endsWith('.png') ||
    fileName.endsWith('.jpg') ||
    fileName.endsWith('.jpeg') ||
    fileName.endsWith('.webp')
  ) {
    try {
      const ai = getGeminiClient();
      const base64Data = buffer.toString('base64');
      
      const imagePart = {
        inlineData: {
          mimeType: normalizedMime.startsWith('image/') ? normalizedMime : 'image/jpeg',
          data: base64Data,
        },
      };

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: [
          imagePart,
          {
            text: 'You are an advanced OCR engine. Transcribe all text, numbers, structured tables, and readable contents from this image. Keep the formatting as readable as possible. Do not include conversational preambles or chat metadata, just output the extracted text content directly.'
          }
        ]
      });

      return response.text || 'No text content could be extracted from this image.';
    } catch (err: any) {
      console.error('Error doing Gemini OCR on image:', err);
      throw new Error(`Failed to process image OCR: ${err.message}`);
    }
  }

  // Fallback: Try decoding as UTF-8 text anyway
  try {
    return buffer.toString('utf-8');
  } catch (err: any) {
    throw new Error(`Unsupported document type and failed raw decode: ${normalizedMime}`);
  }
}
