/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Shield, MessageSquare, Clock, Sun, Moon, LogOut, User } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";

interface NavbarProps {
  onNavigateToLanding: () => void;
  onNavigateToHistory: () => void;
  theme: "light" | "dark";
  onToggleTheme: () => void;
}

export default function Navbar({
  onNavigateToLanding,
  onNavigateToHistory,
  theme,
  onToggleTheme,
}: NavbarProps) {
  const { user, logout } = useAuth();

  return (
    <nav className="sticky top-0 z-50 w-full bg-white/80 dark:bg-slate-950/70 backdrop-blur-md transition-all duration-300">
      <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Logo */}
        <div 
          onClick={onNavigateToLanding}
          className="flex cursor-pointer items-center space-x-3 transition-opacity hover:opacity-80"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-600 shadow-md">
            <Shield className="h-4.5 w-4.5 text-white" />
          </div>
          <span className="font-sans text-lg font-bold tracking-tight text-slate-900 dark:text-white">
            VeriRAG<span className="text-indigo-600 dark:text-indigo-400">.ai</span>
          </span>
        </div>

        {/* Right Actions */}
        <div className="flex items-center space-x-2 sm:space-x-4">
          <button
            onClick={onNavigateToLanding}
            className="flex items-center space-x-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900 transition-colors"
          >
            <MessageSquare className="h-4 w-4" />
            <span className="hidden sm:inline">New Chat</span>
          </button>
          
          <button
            onClick={onNavigateToHistory}
            className="flex items-center space-x-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900 transition-colors"
          >
            <Clock className="h-4 w-4" />
            <span className="hidden sm:inline">History</span>
          </button>

          <div className="h-4 w-px bg-slate-200 dark:bg-slate-800 mx-1"></div>

          <button
            onClick={onToggleTheme}
            className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-900 transition-colors"
            title="Toggle Theme"
          >
            {theme === "dark" ? <Sun className="h-4.5 w-4.5" /> : <Moon className="h-4.5 w-4.5" />}
          </button>

          {user && (
            <>
              <div className="h-4 w-px bg-slate-200 dark:bg-slate-800 mx-1"></div>
              <div className="flex items-center space-x-2 pl-2">
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName || "User"} className="h-8 w-8 rounded-full border border-slate-200 dark:border-slate-700" referrerPolicy="no-referrer" />
                ) : (
                  <div className="h-8 w-8 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400">
                    <User className="h-4 w-4" />
                  </div>
                )}
                <span className="hidden md:inline text-sm font-medium text-slate-700 dark:text-slate-300 mr-2">
                  {user.displayName || user.email}
                </span>
                <button
                  onClick={logout}
                  className="flex items-center justify-center p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/30 dark:hover:text-rose-400 transition-colors"
                  title="Logout"
                >
                  <LogOut className="h-4.5 w-4.5" />
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
