/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from "react";
import { CheckCircle2, AlertCircle, Info, X, AlertTriangle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export interface ToastMessage {
  id: string;
  type: "success" | "error" | "info" | "warning";
  text: string;
}

interface ToastContainerProps {
  toasts: ToastMessage[];
  onRemove: (id: string) => void;
}

export default function ToastContainer({ toasts, onRemove }: ToastContainerProps) {
  return (
    <div 
      className="fixed top-4 right-4 z-50 flex flex-col space-y-3 max-w-sm w-full pointer-events-none px-4 sm:px-0"
      id="toast-notifications-root"
    >
      <AnimatePresence>
        {toasts.map((toast) => (
          <ToastItem key={toast.id} toast={toast} onRemove={onRemove} />
        ))}
      </AnimatePresence>
    </div>
  );
}

interface ToastItemProps {
  key?: string;
  toast: ToastMessage;
  onRemove: (id: string) => void;
}

function ToastItem({ toast, onRemove }: ToastItemProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onRemove(toast.id);
    }, 6000); // 6 seconds auto-dismiss
    return () => clearTimeout(timer);
  }, [toast.id, onRemove]);

  const getToastStyle = (type: ToastMessage["type"]) => {
    switch (type) {
      case "success":
        return {
          borderClass: "border-emerald-500/30",
          bgClass: "bg-emerald-950/80 text-emerald-300",
          iconColor: "text-emerald-400",
          icon: CheckCircle2,
          badge: "SUCCESS",
        };
      case "error":
        return {
          borderClass: "border-rose-500/30",
          bgClass: "bg-rose-950/80 text-rose-300",
          iconColor: "text-rose-400",
          icon: AlertCircle,
          badge: "EXCEPTION",
        };
      case "warning":
        return {
          borderClass: "border-amber-500/30",
          bgClass: "bg-amber-950/80 text-amber-300",
          iconColor: "text-amber-400",
          icon: AlertTriangle,
          badge: "WARNING",
        };
      case "info":
      default:
        return {
          borderClass: "border-indigo-500/30",
          bgClass: "bg-indigo-950/80 text-indigo-300",
          iconColor: "text-indigo-400",
          icon: Info,
          badge: "TELEMETRY",
        };
    }
  };

  const style = getToastStyle(toast.type);
  const Icon = style.icon;

  return (
    <motion.div
      initial={{ opacity: 0, x: 50, y: -10, scale: 0.95 }}
      animate={{ opacity: 1, x: 0, y: 0, scale: 1 }}
      exit={{ opacity: 0, x: 50, scale: 0.95, transition: { duration: 0.2 } }}
      layout
      className={`pointer-events-auto flex w-full items-start gap-3 rounded-xl border ${style.borderClass} ${style.bgClass} backdrop-blur-md p-4 shadow-2xl relative overflow-hidden`}
      id={`toast-message-${toast.id}`}
    >
      {/* Accent left highlight strip */}
      <div className={`absolute left-0 top-0 bottom-0 w-1 bg-current opacity-80`} />

      <Icon className={`h-5 w-5 shrink-0 mt-0.5 ${style.iconColor}`} />
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center space-x-1.5 mb-1">
          <span className="font-mono text-[8px] font-bold tracking-wider uppercase bg-black/40 px-1.5 py-0.5 rounded text-white/80">
            {style.badge}
          </span>
        </div>
        <p className="font-sans text-[11px] leading-relaxed font-medium">
          {toast.text}
        </p>
      </div>

      <button
        onClick={() => onRemove(toast.id)}
        className="text-slate-400 hover:text-white transition-colors shrink-0 p-0.5 rounded hover:bg-white/5 cursor-pointer"
        aria-label="Dismiss notification"
      >
        <X className="h-4 w-4" />
      </button>
    </motion.div>
  );
}
