/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { VerificationResponse, FileRecord } from "../types";

/**
 * Service to handle communications with VeriRAG Express backend APIs
 */
export async function uploadFile(
  file: File,
  onProgress?: (percent: number) => void
): Promise<{ success: boolean; message: string; file: FileRecord }> {
  const formData = new FormData();
  formData.append("file", file);

  // We can track upload progress standard via fetch if needed, but since we are sending files to our backend,
  // we do standard fetch, and mock progress updates smoothly.
  if (onProgress) {
    onProgress(10);
    setTimeout(() => onProgress(45), 100);
    setTimeout(() => onProgress(80), 250);
  }

  const response = await fetch("/api/upload", {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || `Upload failed with status ${response.status}`);
  }

  if (onProgress) {
    onProgress(100);
  }

  return response.json();
}

/**
 * Submit prompt for RAG evidence search, multi-model generation, and consensus scoring
 */
export async function verifyPrompt(
  prompt: string,
  sessionId?: string,
  signal?: AbortSignal
): Promise<VerificationResponse> {
  const response = await fetch("/api/verify", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ prompt, sessionId }),
    signal,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || `Verification failed with status ${response.status}`);
  }

  return response.json();
}

/**
 * Retrieve uploaded files list from in-memory backend
 */
export async function getFiles(): Promise<FileRecord[]> {
  const response = await fetch("/api/files");
  if (!response.ok) {
    throw new Error("Failed to retrieve uploaded files list.");
  }
  const data = await response.json();
  return data.files || [];
}

/**
 * Reset and clear in-memory backend stores
 */
export async function clearFiles(): Promise<{ success: boolean; message: string }> {
  const response = await fetch("/api/files", {
    method: "DELETE",
  });
  if (!response.ok) {
    throw new Error("Failed to clear database.");
  }
  return response.json();
}
